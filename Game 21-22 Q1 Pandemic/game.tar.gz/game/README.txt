title:      PANDEMIC

author(s):  Martí Oller


contact:    ollerriera.mart@gmail.com

(c) Universitat Politècnica de Catalunya, 2021
