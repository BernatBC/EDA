#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main (int argc, char *argv[]){
  char buff[120];
  if (argc != 6) {
	  sprintf(buff, "Please indicate: number_games player1 player2 player3 player4\n");
	  write(1,buff,strlen(buff));
    exit(-1);
  }
  int n_games = atoi(argv[1]);
  int classified1 = 0;
  int classified2 = 0;
  int classified3 = 0;
  int classified4 = 0;
  sprintf(buff, "Starting simulation\n");
  write(1,buff,strlen(buff));
  for (int i = 1; i <= n_games; ++i) {
    int s = rand()%10000000;
    char seed[20];
    sprintf(seed, "%d\n", s);
    char file[20];
    sprintf(file, "%d.out\n", seed);
    char file2[20];
    sprintf(file2, "%d.txt\n", seed);
    int pid = fork();
    if (pid == 0) {
      execlp ("./Game", "Game", argv[2], argv[3], argv[4], argv[5], "-s", seed, "-i", "default.cnf", "-o", file, (char *) 0);
      sprintf(buff, "Execlp error: game %d ignored\n", i);
  	  write(1,buff,strlen(buff));
      exit(-1);
    }
    else if (pid == -1) {
      sprintf(buff, "Fork error: game %d ignored\n", i);
  	  write(1,buff,strlen(buff));
      exit(-1);
    }
    waitpid(pid, NULL, 0);
    //Calculate result

    sprintf(buff, "Game %d of %d played\n", i, n_games);
    write(1,buff,strlen(buff));
  }
  sprintf(buff, "----------\n");
  write(1,buff,strlen(buff));
  sprintf(buff, "Classification rates\n");
  write(1,buff,strlen(buff));
  float c1 = 100*classified1/n_games;
  sprintf(buff, "%s: %f %\n", argv[2], c1);
  write(1,buff,strlen(buff));
  float c2 = 100*classified2/n_games;
  sprintf(buff, "%s: %f %\n", argv[3], c2);
  write(1,buff,strlen(buff));
  float c3 = 100*classified3/n_games;
  sprintf(buff, "%s: %f %\n", argv[4], c3);
  write(1,buff,strlen(buff));
  float c4 = 100*classified4/n_games;
  sprintf(buff, "%s: %f %\n", argv[5], c4);
  write(1,buff,strlen(buff));
  sprintf(buff, "----------\n");
  write(1,buff,strlen(buff));
}
